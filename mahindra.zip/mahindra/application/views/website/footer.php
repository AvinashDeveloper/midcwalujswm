    <footer>
      <div class="ct-prefooter ct-u-backgroundGray ct-u-paddingBoth70">
        <div class="container">
          <div class="row">
            <div class="col-lg-6 ">
              <div class="widget ct-widget-contact">
                <h3 class="ct-widget-header text-uppercase ct-fw-400">Contact us</h3>
                <h6>Address</h6>
                <h4>486 Engine Avenue Windshield, CA 87301</h4>
                <h6>Phone</h6>
                <a href="tel:9094502735" class="ct-u-colorLightBlack"><h4>909.450.2735</h4></a>
                <h6>Email</h6>
                <a href="mailto:info@rotaautoservice.com" class="ct-u-colorLightBlack"><h4>
                info@rotaautoservice.com</h4></a>
              </div>
            </div>
            <div class="col-lg-6">
                            <div class="widget ct-widget-services">
                                <h3 class="ct-widget-header text-uppercase ct-fw-400">Our company</h3>
                                <ul>
                                    <li><a href="<?=base_url('/');?>">Home</a></li>
                                    <li><a href="<?=base_url('Contact-us');?>">Contact us</a></li>
                                </ul>
                            </div>
                        </div>
         
         
          </div>
        </div>
      </div>
      <div class="ct-postfooter container ct-u-paddingBoth20">
        <div class="row">
          <div class="col-lg-9 col-md-6 ct-copyright">
            <p>© 2020 xyz Auto Service. All rights reserved. Design by <a
              href="#" target="_blank">Hotbit</a>
            </p>
          </div>
         
        </div>
      </div>
    </footer>
    <a href="#MainHeader" class="ct-js-btnScrollUp ct-btnScrollUp">
      <i
      class="fa fa-angle-up text-center"></i>
    </a>
  </div>
  <script src="<?=base_url('assets/website/'); ?>assets/js/jquery.min.js"></script>
  <script src="<?=base_url('assets/website/'); ?>assets/bootstrap/js/bootstrap.min.js"></script>
  <script src="<?=base_url('assets/website/'); ?>assets/js/device.min.js"></script>
  <script src="<?=base_url('assets/website/'); ?>assets/js/browser.min.js"></script>
  <script src="<?=base_url('assets/website/'); ?>assets/js/jquery.placeholder.min.js"></script>
  <script id="googleMap" type="text/javascript" src="https://maps.googleapis.com/maps/api/js?"></script>
  <script src="<?=base_url('assets/website/'); ?>assets/js/lightgallery/lightgallery-all.js"></script>
  <script src="<?=base_url('assets/website/'); ?>assets/js/main.js"></script>
  <script src="<?=base_url('assets/website/'); ?>assets/plugins/slick/slick.min.js"></script>
  <script src="<?=base_url('assets/website/'); ?>assets/plugins/slick/init.js"></script>
</body>
</html>