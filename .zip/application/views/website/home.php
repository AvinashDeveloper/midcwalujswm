<?php $this->load->view("website/header"); ?>
<style>
.image img
{
    height:200px;
    width:100%;
}
h3.gallery_title {
    position: absolute;
    top: 50%;
    left: 50%;
    transform: translate(-50%, -50%);
    color: #fff;
}
</style>
    <div class="ct-slick ct-js-slick ct-mainSlider ct-slick-arrow--type1 ct-slick-dots--type1" data-autoplay="false" data-arrows="true" data-dots="true" data-items="1" data-height="550">
        <?php $slider = GetSliderInfo();
            if(!empty($slider)){
                foreach($slider as $value){
        ?>
        <div class="item" data-background="<?=base_url().slider_image_url.$value['slider_image']; ?>" data-height="550">
            <div class="item-inner container">
                <div class="row">
                    <div class="col-lg-5 col-md-6 col-sm-8 col-xs-10 slider-header">
                
                    </div>
                </div>
            </div>
        </div>
        <?php
                }
            }
        ?>
    </div>
    <div class="ct-iconBoxes ct-u-backgroundLightGray text-uppercase" data-height="149">
        <div class="container">
            <div class="row">
                <div class="col-lg-12 col-sm-6 ct-u-paddingTop50 ">
                    <a href="https://www.trackinggenie.com/">
                        <div class="media directions">
                            <div class="media-left">
                                <img class="media-object directions" src="<?=base_url('assets/website/'); ?>assets/images/demo-content/img_trans.png" alt="directions">
                            </div>
                            <div class="media-body">
                                <h3 class="media-heading">Track your Vechicle</h3>
                            </div>
                        </div>
                    </a>
                    <div class="break-line"><img src="<?=base_url('assets/website/'); ?>assets/images/demo-content/break-line.png" alt=" "></div>
                </div>
               
            </div>
        </div>
    </div>
    <div class="container ct-services ct-u-marginBoth80">
        <div class="row">
            <!-- <a href="preventive_maintenance.html"> -->
            <?php $gallery = GetGalleryInfo();
                if(!empty($gallery)){
                    $i = 0;
                    foreach($gallery as $value){
                        // if($i == 7){
                        // break;
                        // }
            ?>
                <div class="col-md-3"><!-- ct-item-hover ct-item-hover--big -->
                    <div class="outer">
                        <div class="inner">
                            <div class="image">
                                <img class="img-responsive" src="<?=base_url().gallery_image_url.$value['image_name']; ?>" alt="<?=$value['image_title'];?>">
                                <h3 class="gallery_title">
                                    <?=$value['image_title'];?>
                                </h3>
                            </div>
                        </div>
                    </div>
                </div>
            <?php
                $i++;}
                }
            ?>
            <!-- </a> -->
       
        </div>
    </div>
    <div class="ct-description" data-height="450">
        <div class="container ct-u-paddingTop70 ct-u-paddingBottom100">
            <div class="row">
                <div class="col-lg-12">
                    <h1 class="ct-description--header ct-fw-700">Introduction</h1>
                    <p class="ct-fw-400">
                        Aenean semper nisi ut neque molestie posuere ac id tortor. Nam ut massa
                        tincidunt, volutpat sapien sed,
                        gravida velit. Proin ut vehicula massa. Aenean sit amet metus ante. Donec ut nisl augue
                        pellentesque.Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
                        tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,
                        quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo
                        consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse
                        cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
                    </p>
                    <p>
                        tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,
                        quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo
                        consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse
                        cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.
                    </p>
                    <p>
                        tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,
                        quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo
                        consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse
                        cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.
                    </p>
                </div>
            </div>
        </div>
    </div>
    <!-- <div class="ct-gallery ct-u-paddingTop70" data-height="425">
        <h3 class="text-center text-uppercase ct-u-paddingBoth20">Our gallery</h3>
        <div class="container">
            <div class="ct-slick ct-light-gallery ct-u-marginBottom30 ct-js-slick ct-slick-arrow--type1 ct-slick-dots--type1 ct-js-lightGallery" data-autoplay="false"
            data-arrows="true" data-dots="false" data-items="1" data-items-xs="2" data-items-sm="3" data-items-md="4"
            data-items-lg="6" data-height="165">
                <a href="<?=base_url('assets/website/'); ?>assets/images/demo-content/pic_1_large.jpg">
                    <div class="item">
                        <div class="item-inner">
                            <img src="<?=base_url('assets/website/'); ?>assets/images/demo-content/pic_1.jpg" alt="">
                        </div>
                    </div>
                </a>
                <a href="<?=base_url('assets/website/'); ?>assets/images/demo-content/pic_2_large.jpg">
                    <div class="item">
                        <div class="item-inner">
                            <img src="<?=base_url('assets/website/'); ?>assets/images/demo-content/pic_2.jpg" alt="">
                        </div>
                    </div>
                </a>
                <a href="<?=base_url('assets/website/'); ?>assets/images/demo-content/pic_3_large.jpg">
                    <div class="item">
                        <div class="item-inner">
                            <img src="<?=base_url('assets/website/'); ?>assets/images/demo-content/pic_3.jpg" alt="">
                        </div>
                    </div>
                </a>
                <a href="<?=base_url('assets/website/'); ?>assets/images/demo-content/pic_4_large.jpg">
                    <div class="item">
                        <div class="item-inner">
                            <img src="<?=base_url('assets/website/'); ?>assets/images/demo-content/pic_4.jpg" alt="">
                        </div>
                    </div>
                </a>
                <a href="<?=base_url('assets/website/'); ?>assets/images/demo-content/pic_5_large.jpg">
                    <div class="item">
                        <div class="item-inner">
                            <img src="<?=base_url('assets/website/'); ?>assets/images/demo-content/pic_5.jpg" alt="">
                        </div>
                    </div>
                </a>
                <a href="<?=base_url('assets/website/'); ?>assets/images/demo-content/pic_6_large.jpg">
                    <div class="item">
                        <div class="item-inner">
                            <img src="<?=base_url('assets/website/'); ?>assets/images/demo-content/pic_6.jpg" alt="">
                        </div>
                    </div>
                </a>
            </div>
        </div>
    </div> -->
    <div class="ct-mapSection ct-u-backgroundLightBlack" data-height="568" id="ct-mapSection">
        <div class="container-fluid">
            <div class="row">
                <div class="col-lg-5 col-md-12 col-sm-12 ct-contact">
                    <div class="widget ct-widget-contact ct-widget-contact--map">
                        <h3 class="ct-widget-header text-uppercase ct-fw-400">Get in touch</h3>
                        <h6 class="address">Address</h6>
                        <h4>486 Engine Avenue, Windshield, CA 87301</h4>
                        <h6 class="phone">Phone</h6>
                        <a href="tel:9094567890"><h4>(909) 456-7890</h4></a>
                        <h6>Hours of operation</h6>
                        <h4>Mon—Fri: 8:00am—5:30pm</h4>
                        <h4>Sat: 8:00am—4:30pm</h4>
                        <h4>Sun: Closed</h4>
                        <a href="contact.html" class="btn btn-white ct-u-marginTop20">Send Us A Message</a>
                    </div>
                </div>
                <div class="col-lg-7 col-md-12 col-sm-12">
                <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d120073.0745760079!2d75.23516030129642!3d19.87024401442712!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3bdb9815a369bc63%3A0x712d538b29a2a73e!2sAurangabad%2C%20Maharashtra!5e0!3m2!1sen!2sin!4v1602334656971!5m2!1sen!2sin" width="100%" height="450" frameborder="0" style="border:0;" allowfullscreen="" aria-hidden="false" tabindex="0"></iframe>
                </div>
            </div>
        </div>
    </div>
    <!-- <div class="ct-logosSection ct-u-paddingBoth50" data-height="160">
        <div class="container">
            <div class="ct-slick ct-js-slick ct-mainSlider ct-slick-arrow--type1 ct-slick-dots--type1"
            data-autoplay="false"
            data-arrows="true" data-dots="false" data-items="2" data-items-sm="4" data-items-md="5"
            data-items-lg="7"
            data-height="65">
                <div class="item">
                    <div class="item-inner">
                        <img src="<?=base_url('assets/website/'); ?>assets/images/demo-content/car-logo-1.jpg" alt="">
                    </div>
                </div>
                <div class="item">
                    <div class="item-inner">
                        <img src="<?=base_url('assets/website/'); ?>assets/images/demo-content/car-logo-2.jpg" alt="">
                    </div>
                </div>
                <div class="item">
                    <div class="item-inner">
                        <img src="<?=base_url('assets/website/'); ?>assets/images/demo-content/car-logo-3.jpg" alt="">
                    </div>
                </div>
                <div class="item">
                    <div class="item-inner">
                        <img src="<?=base_url('assets/website/'); ?>assets/images/demo-content/car-logo-4.jpg" alt="">
                    </div>
                </div>
                <div class="item">
                    <div class="item-inner">
                        <img src="<?=base_url('assets/website/'); ?>assets/images/demo-content/car-logo-5.jpg" alt="">
                    </div>
                </div>
                <div class="item">
                    <div class="item-inner">
                        <img src="<?=base_url('assets/website/'); ?>assets/images/demo-content/car-logo-6.jpg" alt="">
                    </div>
                </div>
                <div class="item">
                    <div class="item-inner">
                        <img src="<?=base_url('assets/website/'); ?>assets/images/demo-content/car-logo-7.jpg" alt="">
                    </div>
                </div>
            </div>
        </div>
    </div> -->
    <footer>
        <div class="ct-postfooter container ct-u-paddingBoth20">
            <div class="row">
                <div class="col-lg-9 col-md-6 ct-copyright">
                    <p>© 2020 xyz Auto Service. All rights reserved. Design by <a
                        href="https://www.Hotbitinfotech.com" target="_blank">Hotbit</a>
                    </p>
                </div>
            
            </div>
        </div>
    </footer>
    <a href="#MainHeader" class="ct-js-btnScrollUp ct-btnScrollUp">
        <i class="fa fa-angle-up text-center"></i>
    </a>
</div>
    <script src="<?=base_url('assets/website/'); ?>assets/js/jquery.min.js"></script>
    <script src="<?=base_url('assets/website/'); ?>assets/bootstrap/js/bootstrap.min.js"></script>
    <script src="<?=base_url('assets/website/'); ?>assets/js/device.min.js"></script>
    <script src="<?=base_url('assets/website/'); ?>assets/js/browser.min.js"></script>
    <script src="<?=base_url('assets/website/'); ?>assets/js/jquery.placeholder.min.js"></script>
    <script id="googleMap" type="text/javascript" src="https://maps.googleapis.com/maps/api/js?"></script>
    <script src="<?=base_url('assets/website/'); ?>assets/js/lightgallery/lightgallery-all.js"></script>
    <script src="<?=base_url('assets/website/'); ?>assets/js/main.js"></script>
    <script src="<?=base_url('assets/website/'); ?>assets/plugins/slick/slick.min.js"></script>
    <script src="<?=base_url('assets/website/'); ?>assets/plugins/slick/init.js"></script>
    <script src="demo/js/demo.js"></script>
</body>
</html>