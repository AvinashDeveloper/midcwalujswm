<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

    class Website_model extends CI_Model{

    }
?>